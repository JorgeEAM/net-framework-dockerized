<#
    Functions Block
#>
Function Add-Path($Path) {
    $Path = [Environment]::GetEnvironmentVariable("PATH", "Machine") + [IO.Path]::PathSeparator + $Path
    [Environment]::SetEnvironmentVariable( "Path", $Path, "Machine" )
}


$env:path = "${env:path};C:\Windows\System32\inetsrv";
Expand-Archive -Path "..\DemoApplication.zip" -DestinationPath "C:\source\DemoApplication"
Write-Host $env:path;

<#
    Remove default web site content.
#>
Remove-Website -Name 'Default Web Site';
Remove-Item -Recurse -Force C:\inetpub\wwwroot\*;

<#
    Creating WebSite and Application configuration. 
#>

$info=Get-Content ".\applicationInfo.json" | ConvertFrom-Json

# AppPool Creation
appcmd add apppool /name:$($info.IISitePool.name) /managedRuntimeVersion:$($info.IISitePool.managedRuntimeVersion) /managedPipelineMode:Integrated
# Setting features
$info.IISitePool.features | ForEach-Object {
    appcmd set apppool "$($info.IISitePool.name)" /$($_.PSObject.Properties.Name):$($_.PSObject.Properties.Value)
}

# Site Creation
appcmd add site /name:$($info.IISiteServer.name) /physicalPath:$($info.IISiteServer.physicalpath) /bindings:http/*:80:
appcmd start site "$($info.IISiteServer.name)"
# Setting features
$info.IISiteServer.features | ForEach-Object {
    appcmd set site "$($info.IISiteServer.name)" /$($_.PSObject.Properties.Name):$($_.PSObject.Properties.Value)
}

# VirtualApp Creation
appcmd add app /site.name:$($info.IISiteServer.name) /path:/$($info.IISiteApp.name) /physicalPath:$($info.IISiteApp.physicalpath)
# Setting relation between VirtualApp and AppPool
appcmd set app "$($info.IISiteServer.name)/$($info.IISiteApp.name)" /applicationPool:"$($info.IISitePool.name)"
# Setting features
$info.IISiteApp.features | ForEach-Object {
    appcmd set app "$($info.IISiteServer.name)/$($info.IISiteApp.name)" /$($_.PSObject.Properties.Name):$($_.PSObject.Properties.Value)
}


Get-ChildItem -Recurse -Path "C:\source\DemoApplication\*" | Move-Item -Destination "C:\inetpub\wwwroot\$($info.IISiteApp.name)";

